create function my_clob_substr(c in clob) return varchar2
as
    v_characters number := 201;
    v_length     number := 201;
begin
    while v_length > 200
        loop

            v_characters := v_characters - 1;

            v_length := lengthb(dbms_lob.substr(c, v_characters, 1));

        end loop;

    return dbms_lob.substr(c, v_characters, 1);

end;
/

