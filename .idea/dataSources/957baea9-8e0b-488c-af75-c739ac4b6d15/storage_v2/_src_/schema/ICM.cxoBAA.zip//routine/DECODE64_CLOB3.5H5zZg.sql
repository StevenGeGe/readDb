create function decode64_clob3(p_clob_encoded clob)
    return clob
    is
    l_clob_encoded clob;
    l_clob_decoded clob;
    l_substring varchar2(2048);
    l_substring_length pls_integer := 2048;
    l_pos pls_integer := 1;
begin
    l_clob_encoded := replace(replace(p_clob_encoded, chr(10), null), chr(13), null);
    dbms_lob.createtemporary(l_clob_decoded, false);
    while l_pos <= dbms_lob.getlength(l_clob_encoded)
        loop
            l_substring := dbms_lob.substr(l_clob_encoded, l_substring_length, l_pos);
            if l_substring is null then
                exit;
            end if;
            dbms_lob.append(l_clob_decoded,
                            utl_raw.cast_to_varchar2(utl_encode.base64_decode(utl_raw.cast_to_raw(l_substring))));
            l_pos := l_pos + length(l_substring);
        end loop;

    return l_clob_decoded;
end;
/

